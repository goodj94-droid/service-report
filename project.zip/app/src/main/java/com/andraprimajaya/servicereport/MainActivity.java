package com.andraprimajaya.servicereport;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    public class Bridge {
        @JavascriptInterface
        public void openUrl(String url) {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka link", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void savePdf(String base64, String fileName) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);

                File dir = new File(getCacheDir(), "pdf");
                if (!dir.exists()) dir.mkdirs();
                File cached = new File(dir, fileName);
                try (FileOutputStream fos = new FileOutputStream(cached)) {
                    fos.write(data);
                }

                String where = saveToDownloads(data, fileName);
                runOnUiThread(() -> showDone(cached, where));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Gagal menyimpan PDF: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    private String saveToDownloads(byte[] data, String fileName) throws Exception {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/ServiceReport");
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (uri == null) throw new Exception("tidak bisa membuat file di Download");
            try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                os.write(data);
            }
            return "Download/ServiceReport";
        } else {
            File d = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
            if (d != null && !d.exists()) d.mkdirs();
            File f = new File(d, fileName);
            try (FileOutputStream fos = new FileOutputStream(f)) {
                fos.write(data);
            }
            return f.getParent();
        }
    }

    private void showDone(File file, String where) {
        new AlertDialog.Builder(this)
                .setTitle("PDF tersimpan")
                .setMessage(file.getName() + "\n\nLokasi: " + where)
                .setPositiveButton("Bagikan", (d, w) -> share(file))
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void share(File file) {
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", file);
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("application/pdf");
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Bagikan PDF"));
    }
}
